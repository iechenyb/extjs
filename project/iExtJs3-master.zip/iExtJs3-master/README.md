# iExtJs3

一个基于ExtJs3实现，简洁完整的后台管理系统入门实例

系统简介：http://blog.csdn.net/hwhsong/article/details/50479147